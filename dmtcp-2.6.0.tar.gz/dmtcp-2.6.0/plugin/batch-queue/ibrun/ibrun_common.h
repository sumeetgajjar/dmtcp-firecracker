#ifndef IBRUN_COMMON_H
#define IBRUN_COMMON_H

typedef struct unique_id
{
  int node_id;
  int process_id;
} unique_id;

#endif

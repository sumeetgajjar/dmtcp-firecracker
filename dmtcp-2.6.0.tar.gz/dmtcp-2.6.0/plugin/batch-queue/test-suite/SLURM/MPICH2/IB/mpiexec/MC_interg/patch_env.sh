source ../../../../../dmtcp_env.sh
source ../../../../../openmpi_env.sh
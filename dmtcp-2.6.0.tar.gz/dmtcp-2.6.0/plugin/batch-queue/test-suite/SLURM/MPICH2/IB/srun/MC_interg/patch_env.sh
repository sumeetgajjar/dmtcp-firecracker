source ../../../../../dmtcp_env.sh
source ../../../../../mpich2_env.sh
#!/bin/bash

SLURM_PMI_INC="/opt/slurm-2.6.5/include/slurm/"
SLURM_PMI_LIB="/opt/slurm-2.6.5/lib/"
